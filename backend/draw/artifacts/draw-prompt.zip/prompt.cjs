"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers/prompt.ts
var prompt_exports = {};
__export(prompt_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(prompt_exports);

// src/lib/http.ts
var allowedOrigins = /* @__PURE__ */ new Set([
  "https://subaru-is-running.com",
  "http://localhost:4321",
  "http://localhost:3000"
]);
var corsHeaders = (origin) => {
  const allowed = origin && allowedOrigins.has(origin) ? origin : "https://subaru-is-running.com";
  return {
    "Access-Control-Allow-Origin": allowed,
    "Access-Control-Allow-Headers": "Content-Type, X-Requested-With",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
  };
};
var parseJson = (event) => {
  if (!event?.body)
    return {};
  try {
    const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};
var json = (statusCode, body, origin) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    ...corsHeaders(origin)
  },
  body: JSON.stringify(body)
});
var options = (origin) => ({
  statusCode: 204,
  headers: corsHeaders(origin),
  body: ""
});

// src/lib/prompt.ts
var BASE_YEAR = 2026;
var BASE_MONTH = 2;
var TOPICS = [
  "\u718A",
  "\u732B",
  "\u72AC",
  "\u3046\u3055\u304E",
  "\u30D1\u30F3\u30C0",
  "\u304D\u3064\u306D",
  "\u30DA\u30F3\u30AE\u30F3",
  "\u30D5\u30AF\u30ED\u30A6",
  "\u30A4\u30EB\u30AB",
  "\u304F\u3058\u3089",
  "\u30E9\u30A4\u30AA\u30F3",
  "\u30BE\u30A6",
  "\u30AD\u30EA\u30F3",
  "\u30AB\u30E1",
  "\u30BF\u30B3",
  "\u30AB\u30CB",
  "\u3044\u3061\u3054",
  "\u308A\u3093\u3054",
  "\u30D0\u30CA\u30CA",
  "\u30B3\u30FC\u30D2\u30FC\u30AB\u30C3\u30D7",
  "\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC",
  "\u304A\u306B\u304E\u308A",
  "\u5BCC\u58EB\u5C71",
  "\u96F2",
  "\u96EA\u3060\u308B\u307E",
  "\u8679",
  "\u81EA\u8EE2\u8ECA",
  "\u96FB\u8ECA",
  "\u30ED\u30B1\u30C3\u30C8",
  "\u5BB6",
  "\u89B3\u89A7\u8ECA",
  "\u685C",
  "\u3072\u307E\u308F\u308A",
  "\u30B5\u30DC\u30C6\u30F3",
  "\u30AE\u30BF\u30FC",
  "\u30ED\u30DC\u30C3\u30C8"
];
var pad2 = (v) => String(v).padStart(2, "0");
var jstNow = () => new Date((/* @__PURE__ */ new Date()).toLocaleString("en-US", { timeZone: "Asia/Tokyo" }));
var getCurrentMonthJst = () => {
  const now = jstNow();
  return `${now.getFullYear()}-${pad2(now.getMonth() + 1)}`;
};
var normalizeMonth = (month) => {
  const raw = String(month || "").trim();
  if (!/^\d{4}-\d{2}$/.test(raw))
    return null;
  const year = Number(raw.slice(0, 4));
  const mon = Number(raw.slice(5, 7));
  if (Number.isNaN(year) || Number.isNaN(mon) || mon < 1 || mon > 12)
    return null;
  return `${year}-${pad2(mon)}`;
};
var monthFromPromptId = (promptId) => {
  const raw = String(promptId || "").trim();
  const m = /^prompt-(\d{4}-\d{2})$/.exec(raw);
  return m ? normalizeMonth(m[1]) : null;
};
var monthDiffFromBase = (month) => {
  const year = Number(month.slice(0, 4));
  const mon = Number(month.slice(5, 7));
  return (year - BASE_YEAR) * 12 + (mon - BASE_MONTH);
};
var resolveDrawPrompt = (input) => {
  const month = normalizeMonth(input?.month) || monthFromPromptId(input?.promptId) || getCurrentMonthJst();
  const diff = monthDiffFromBase(month);
  const idx = (diff % TOPICS.length + TOPICS.length) % TOPICS.length;
  const topic = TOPICS[idx];
  const dateJst = (() => {
    const now = jstNow();
    return `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`;
  })();
  return {
    promptId: `prompt-${month}`,
    dateJst,
    promptText: `30\u79D2\u3067${topic}\u3092\u63CF\u3044\u3066`,
    month,
    topic
  };
};

// src/handlers/prompt.ts
var handler = async (event) => {
  const origin = event?.headers?.origin || event?.headers?.Origin;
  if (event?.requestContext?.http?.method === "OPTIONS")
    return options(origin);
  try {
    const month = event?.queryStringParameters?.month;
    const prompt = resolveDrawPrompt({ month });
    return json(200, {
      promptId: prompt.promptId,
      dateJst: prompt.dateJst,
      promptText: prompt.promptText
    }, origin);
  } catch (err) {
    return json(500, { error: err?.message || "failed" }, origin);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
module.exports = { handler };
//# sourceMappingURL=prompt.cjs.map
